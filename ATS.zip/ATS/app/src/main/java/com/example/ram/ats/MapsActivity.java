package com.example.ram.ats;

/**
 * Created by Ram on 2/24/2016.
 */
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,LocationListener{

    private GoogleMap mMap;
    ArrayList<Location> coordList = new ArrayList<Location>();
    float distance;
    Marker marker;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }






    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        String bestProvider = locationManager.getBestProvider(criteria, true);
        Location location = locationManager.getLastKnownLocation(bestProvider);
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        coordList.add(location);
        LatLng latLng = new LatLng(latitude, longitude);
        mMap.addMarker(new MarkerOptions().position(latLng));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(20));
        onLocationChanged(location);
        locationManager.requestLocationUpdates(bestProvider,5 , 5, this);
    }
    public void onLocationChanged(Location location) {
        coordList.add(location);
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        LatLng latLng = new LatLng(latitude, longitude);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        //mMap.animateCamera(CameraUpdateFactory.zoomTo(20));
        updateUI(latitude, longitude,distance);

    }
    void updateUI(double latitude,double longitude,float distance)
    {
        TextView locationTv = (TextView) findViewById(R.id.latlongLocation);
        locationTv.setText("Lat:" + latitude + " Long:" + longitude+ "Csize:" + coordList.size()+"Dist"+distance);
        drawPrimaryLinePath(coordList);
    }
    ;
    private void drawPrimaryLinePath( ArrayList<Location> coordList )
    {
        if ( mMap == null )
        {
            return;
        }

        if ( coordList.size() < 2 )
        {
            return;
        }

        PolylineOptions options = new PolylineOptions();


        options.color(Color.parseColor("#CC0000FF"));
        options.width(20);
        options.visible(true);
        for ( Location locRecorded : coordList)
        {
            options.add( new LatLng( locRecorded.getLatitude(),
                    locRecorded.getLongitude() ) );
        }

        for(int i=0;i<coordList.size()-1;i++)
        {
            distance=coordList.get(i).distanceTo(coordList.get(i+1));
        }

        mMap.addPolyline( options );

    }


    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    // Add a marker in Sydney and move the camera




}
